# 状态与生命周期模板

> 适用场景：项目存在业务状态流转、审批状态、任务生命周期或对象阶段变化时使用。
> 可不生成/可合并：若状态极少或已包含在业务流程文档中，可跳过；也可与业务流程文档合并。

## 1. 文档目标

- 说明对象从创建到结束的状态变化规则
- 帮助页面、数据、流程对齐状态口径

## 2. 状态流转

```mermaid
stateDiagram-v2
  StateA: {{STATE_A}}
  StateB: {{STATE_B}}

  [*] --> StateA
  StateA --> StateB: {{TRANSITION_EVENT}}
  StateB --> [*]
```

## 3. 状态说明

| 状态 | 进入条件 | 可执行动作 | 退出条件 |
|------|------|------|------|
| `{{STATE_NAME}}` | `{{ENTER_CONDITION}}` | `{{AVAILABLE_ACTIONS}}` | `{{EXIT_CONDITION}}` |

## 4. 异常与待确认

- `{{OPEN_ISSUE}}`
